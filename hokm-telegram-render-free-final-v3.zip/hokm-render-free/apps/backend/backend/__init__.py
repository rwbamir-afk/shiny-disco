"""Hokm Platform backend."""

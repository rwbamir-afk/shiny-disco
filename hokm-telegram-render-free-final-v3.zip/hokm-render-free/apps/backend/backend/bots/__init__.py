"""Backend bot strategies."""
